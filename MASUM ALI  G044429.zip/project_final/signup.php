
<?php
session_start();
$ip="localhost";
$user="root";
$password="";
$dbname="result";
$con=mysqli_connect($ip,$user,$password,$dbname);

if (!mysqli_connect_error()){
	echo "";
}else{
	echo "database not coonect";
}
if (isset($_POST['submit'])) {
	$gender=$_POST['gender'];
	$subject=$_POST['user_job'];
	$name=$_POST['name'];
	$PASS=$_POST['password'];
	$email=$_POST['email'];
	$fathername=$_POST['father_name'];
	$mothername=$_POST['mother_name'];
	$mobile=$_POST['user_mobile'];



if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email))
{ 
echo "<center><font face='Verdana' size='2' color=red>Invalid email</font></center>";
}else{
}


if(!preg_match('/^[0-9]{11}+$/',$mobile))
{ 
echo "<center><font face='Verdana' size='2' color=red>Invalid mobile</font></center>";
}else{

	$query="SELECT * FROM signin WHERE email='$email' AND password='$PASS'";
	$row=mysqli_query($con,$query);
	$num=mysqli_num_rows($row);
	if ($num==1){
		echo "<script>alert('Your Login Name or Password is taken already and input are empty');</script>";
	}else{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$PASS=$_POST['password'];
	$Query="INSERT INTO signin(`name`,`email`,`password`) VALUES ('{$name}','{$email}','{$PASS}')";
	$res=mysqli_query($con,$Query);
	if ($res && !empty($email) && !empty($PASS)){
		$_SESSION['email']=$email;
		$_SESSION['father']=$fathername;
		$_SESSION['mother']=$mothername;
		$_SESSION['name']=$name;
		$_SESSION['subject']=$subject;
		$_SESSION['gender']=$gender;
		$_SESSION['gopon']=$PASS;
		header("location:signin.php");
		
		
	}else{
		echo "something wrong";
	}
}
}
}
?>
<?php

require ('sign_up.html');

?>
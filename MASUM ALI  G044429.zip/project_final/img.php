<?php
$ip="localhost";
$user="root";
$password="";
$dbname="result";
$dop=0;
$con=mysqli_connect($ip,$user,$password,$dbname);
if (!mysqli_connect_error()) {
	echo "";
}else{
	echo "database not coonect";
}

if (isset($_POST['submit'])) {
	

$upload_image=$_FILES["image"]["name"];

$folder="d:/xampp/htdocs/img/";

move_uploaded_file($_FILES["image"]["tmp_name"],"$folder".$_FILES["image"]["name "]);

$insert_path="INSERT INTO images VALUES('$folder','$upload_image')";

mysqli_query($con,$insert_path);



}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="POST" action="" enctype="multipart/form-data">
 <input type="file" name="image">
 <input type="submit" name="submit" value="Upload">


</body>
</html>
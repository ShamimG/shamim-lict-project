
<?php
session_start();
if(!isset($_SESSION["email"])){
  header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" href="css/style.css">
    <style media="screen">
      h1{
        text-align: center;
        font-family: sans-serif;
      }
      table {
        font-family: sans-serif;
        border-collapse: collapse;
        border-spacing: 0;
        width: 80%;
        border: 1px solid #ddd;
      }
      th, td {
        text-align: left;
        padding: 16px;
      }
      tr:nth-child(even) {
        background-color: #f2f2f2
      }
    </style>


</head>
<body>

<div class="admit">
</div>
<?php
$ip="localhost";
$user="root";
$password="";
$dbname="result";
$dop=0;
$con=mysqli_connect($ip,$user,$password,$dbname);
if (!mysqli_connect_error()) {
  echo "";
}else{
  echo "database not coonect";
}
if(isset($_POST['submit'])) {
  $email=$_POST['email'];
  $PASS=$_POST['password'];
  $query="SELECT `email`,`password` FROM signin WHERE email='$email' AND password='$PASS'";
  $row=mysqli_query($con,$query);
  $num=mysqli_num_rows($row);
 if ( $num==1 && !empty($email) && !empty($PASS)){
		header("location:card.php");
		
	}else{
		echo "<script>alert('Your Login Name or Password is invalid and input are empty');</script>";
	}
  //else{
    //echo "<script>alert('Your Login Name or Password is invalid and input are empty');</script>";
  //}

}
?>
<?php

require ('sign_in.html');

?>


</body>
</html>

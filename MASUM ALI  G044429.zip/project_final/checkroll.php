<?php
session_start();

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php
$top=$_SESSION['gopon'];
$dop=$_SESSION['ROLL'];
if (isset($_POST['submit'])) {
	$NUM=$_POST['number'];
		$uUM=$_POST['password1'];
	if ($NUM==$dop &&$uUM==$top ) {
		header("location:question.php");
	}else{
		echo "roll not matched";
	}
}








?>
<div class="ano">
	<h2>please enter your roll</h2>
</div>

<div class="woo">
<form method="post">
	password:<input type="text" name="password1">
	roll:<input type="number" name="number">
	<input type="submit" name="submit">
</form>
</div>


</body>
</html>
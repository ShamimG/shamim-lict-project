<?php  
session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
require ('back.html');
$top=$_SESSION['gopon'];
$dop=$_SESSION['ROLL'];
if (isset($_POST['submit'])) {
	$NUM=$_POST['number'];
		$uUM=$_POST['password1'];
	if ($NUM==$dop &&$uUM==$top ) {
		header("location:question.php");
	}else{
		echo "roll not matched";
	}
}
?>

</body>
</html>

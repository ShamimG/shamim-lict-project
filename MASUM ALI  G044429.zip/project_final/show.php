<?php

$ip="localhost";
$user="root";
$password="";
$dbname="result";
$dop=0;
$con=mysqli_connect($ip,$user,$password,$dbname);
if (!mysqli_connect_error()) {
	echo "";
}else{
	echo "database not coonect";
}

$select_image="select * from images";

$var=mysqli_query($con,$select_image);

while($row=mysqli_fetch_array($var))
{
 $image_name=$row["name"];
 $image_path=$row["content"];
 echo "img src=/".$image_path." width=100 height=100";
}




?>